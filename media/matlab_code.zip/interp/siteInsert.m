% Given an LR image and the Delaunay triangulation used in creating
% an HR image from some set of LR images, this function incorporates
% the additional LR image into the approximation, to further improve
% the HR image.
%
% Function takes in newRegPts as a representation of the new LR image:
%   Assumption: LR image is N1xN2, where N1 = rows, N2 = columns
%   newRegPts = [xOffset from first image that went into original 
%                triangulation; yOffset]
%               where xOffset = [xOffsetP(1)(1), ..., xOffsetP(1)(N2);
%                                ...
%                                xOffsetP(N1)(1), ..., xOffsetP(N1)(N2)]
%               which implies that newRegPts is N1x2*N2
%
% r = resolution factor
function siteInsert = siteInsert(origTris, newRegPts, r)
% see paper references 38, 39 from the crazy triangles paper

% Spread points out on HR grid
newRegPts = newRegPts*r;

for 
% FOR EACH NEW VERTEX:

% 1. Find which triangles' circumcircles enclose the new vertex
%    (these triangles are now no longer Delaunay).

% 2. Define an insertion polygon by finding the convex hull of the
%    vertices that make up all of the triangles from (1).

% 3. Eliminate all edges from the original triangualation that lie
%    inside the insertion polygon.

% 4. Connect each vertex of the insertion polygon to the inserted
%    vertex with a new edge to generate a new triangulation.

% 5. Update the old triangulation to the new and loop back up to
%    insert the next new vertex.

end