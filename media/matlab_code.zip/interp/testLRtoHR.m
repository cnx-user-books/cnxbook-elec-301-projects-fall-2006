function testLRtoHR = testLRtoHR()

% K = # of images
K = 2;
P1 = imread('ryan1.jpg');
P2 = imread('ryan2.jpg');
% P3 = imread('ryan3.jpg');
% P4 = imread('ryan4.jpg');
% P5 = imread('ryan5.jpg');
% P6 = imread('ryan6.jpg');

lrs1 = makelr(P1, 1, 100, 1/4);
lrs2 = makelr(P2, 1, 100, 1/4);
% lrs3 = makelr(P3, 1, 1/30, 1);
% lrs4 = makelr(P4, 1, 1/30, 1);
% lrs5 = makelr(P5, 1, 1/30, 1);
% lrs6 = makelr(P6, 1, 1/30, 1);

% R = resolution factor
R = 2;
picts = zeros([size(lrs1),6]);
picts(:,:,1) = lrs1;
picts(:,:,2) = lrs2;
% picts(:,:,3) = lrs3;
% picts(:,:,4) = lrs4;
% picts(:,:,5) = lrs5;
% picts(:,:,6) = lrs6;

testLRtoHR = LRtoHR(picts,K,R);

end