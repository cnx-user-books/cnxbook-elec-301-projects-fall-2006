% Given a transfrom matrix to account for horizontal or vertical shifts,
% rotation, scaling (zooming), and projective transformations (pan, tilt),
% this function applies the transform to the image.  Result is a set of 
% points (x,y) that give the locations of the transformed image with 
% respect to the original image (which had standard integer locations,
% counting up from (1,1) in the upper left corner).
%
% r = # of pixels in the y-dimension
% c = # of pixels in the x-dimension
function [x,y] = registerImgs(transform,r,c)

transformed = zeros(3,1);
x = zeros(r,c);
y = zeros(r,c);

for row = 1:r
    transformR = (row-1)/r;    % transform expects points between 0 and 1
    for col = 1:c
        transformC = (col-1)/c;
        transformed = transform*[transformC;transformR;1];
        
        % shift points from 0-1 range to 1-r,1-c ranges 
        x(row,col) = transformed(1)*c + 1;
        y(row,col) = transformed(2)*r + 1;
    end
end

end