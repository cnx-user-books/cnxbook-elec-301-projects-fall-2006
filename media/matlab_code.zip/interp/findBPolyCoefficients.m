% To aid in the approximation of each triangle patch in tri by a
% continuous polynomial, this function finds the 9 c values associated 
% with each polynomial.
function c = findBPolyCoefficients(tri,registeredPts,pixelVals,vGradientVecs)

[totalTris,three] = size(tri);
[totalPoints,two] = size(registeredPts);

%   1. Find the 3 equations for each vertex, and
%      place them in c_equations matrix;
% c_equations = [A for vertex 1;
%                A for vertex 2; ...
%                A for vertex totalPoints]
% c(point,row,:) gives one row from an A matrix
Btotal = zeros(3,totalPoints);
c_equations = zeros(3*totalPoints,3,9);
for pointNum = 1:totalPoints
    % B = [pixVal; x gradient; y gradient] at this vertex
    z = pixelVals(pointNum);
    B = [z; vGradientVecs(pointNum,1); vGradientVecs(pointNum,2)];
    
    % Compile all B matrices into a vector
    Btotal(:,pointNum) = B;
    
    % B = Ac
    x = registeredPts(pointNum,1);
    y = registeredPts(pointNum,2);
    A = [1   x   y   x^2  y^2  x^3     (x^2)*y  x*(y^2)  y^3; ...
         0   1   0   2*x   0   3*(x^2)  2*x*y   y^2      0; ...
         0   0   1   0    2*y  0        x^2     2*x*y    3*(y^2)];
     
    % Compile all A matrices into a vector
    c_equations(pointNum,1,:) = A(1,:);
    c_equations(pointNum,2,:) = A(2,:);
    c_equations(pointNum,3,:) = A(3,:);
end

%   2. Find the c values for each triangle patch
c = zeros(totalTris,9);
c9 = zeros(9,9);
for triNum = 1:totalTris
    p1 = tri(triNum,1);
    p2 = tri(triNum,2);
    p3 = tri(triNum,3);
    
    B9 = [Btotal(:,p1); Btotal(:,p2); Btotal(:,p3)];
    c9 = [c_equations(p1,1,:); c_equations(p1,2,:); c_equations(p1,3,:); ...
          c_equations(p2,1,:); c_equations(p2,2,:); c_equations(p2,3,:); ...
          c_equations(p3,1,:); c_equations(p3,2,:); c_equations(p3,3,:)];
    c(triNum,:) = pinv(c9)*B9;   %linsolve(c9,B9);
end

end