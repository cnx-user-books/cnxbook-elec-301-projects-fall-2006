% Detects large-scale translation, scale, and rotation
% transformation in images using the FFT and a log-polar
% transform.

function [p] = rst_reg(g, h)

% Give me double!
g = double(g);
h = double(h);

% Check that dimensions are the same
if (size(g) ~= size(h))
  error('Images have different dimensions!');
end

% Compute FFT of base images
gf = fft2(g);
hf = fft2(h);

% Filter magnitude spectra
gfilt = hp_filter(abs(gf));
hfilt = hp_filter(abs(hf));

% Convert magnitude spectra to log-polar representation
[gmaglp,base] = logpolar(gfilt);
hmaglp = logpolar(hfilt);

% Apply cross-power spectrum formula (Reddy, Chatterji 96)
% to log-power magnitude spectra
lps = xpowerspec2(gmaglp,hmaglp);

% Location of the largest peak gives the scale and rotation
[lpy, lpx] = find(lps == max(max(lps)));
scale = base ^ (lpx - 1);
angle = (lpy - 1) * 180 / size(g);

% Build a p matrix from this
scalep = [scale     0 0;
              0 scale 0;
              0     0 1];
anglep = [cos(angle) -sin(angle) 0;
          sin(angle)  cos(angle) 0;
                   0           0 1];

% Compose                 
p = scalep * anglep;
% Renormalize
p = p / p(3,3);
% Invert to map h to g instead of the other way around
p = inv(p);
% Renormalize
p = p / p(3,3);

function [cp] = xpowerspec2(a,b)

af = fft2(a);
bf = fft2(b);
cpf = af .* conj(bf) ./ (abs(af) .* abs(bf));
cp = ifft2(cpf);