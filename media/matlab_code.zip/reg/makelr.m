% Input: High-res image, Number of low-res images to produce
% Output: Clean downsampled image, Array of noisy downsampled images
% * Loads a source high resolution image
% * Converts it to grayscale (if needed)
% * Downsamples so the largest dimension is less than 500 px
% * Creates multiple noisy copies of the downsampled image

function [cleanhr, cleanlr, noiselrs] = makelr(hrimg, num, maxhrdim, lrscale)

if nargin < 4
  lrscale = 0.5;
end

% If hrimg is RGB, convert to grayscale
if (size(hrimg,3) > 1)
  hrimg = rgb2gray(hrimg);
end

xlen = size(hrimg,2);
ylen = size(hrimg,1);

% Find scale so that largest dimension becomes 500 px

if (xlen > ylen)
  hrscale = maxhrdim / xlen;
else
  hrscale = maxhrdim / ylen;
end

% Downsample to clean high-res image
cleanhr = imresize(hrimg,hrscale,'bicubic');

% Downsample again for low-res image
cleanlr = imresize(hrimg,hrscale*lrscale,'bicubic');

% Create num noisy copies of cleanlr
noiselrs = cell(num,1);
for i = 1:num
  noiselrs{i} = imnoise(cleanlr,'gaussian');
end
