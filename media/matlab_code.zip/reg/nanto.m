function out = nanto(in, val)

out = in;
out(isnan(in)) = val;